<?php
/* @var $this AccountFlowController */
/* @var $model AccountFlow */

$this->breadcrumbs = array(
    'Account Flows' => array('index'),
    'Manage',
);

$this->menu = array(
    array('label' => 'List AccountFlow', 'url' => array('index')),
    array('label' => 'Create AccountFlow', 'url' => array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$('#account-flow-grid').yiiGridView('update', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<!--<h1>Manage Account Flows</h1>

<p>
    You may optionally enter a comparison operator (<b>&lt;</b>, <b>&lt;=</b>, <b>&gt;</b>, <b>&gt;=</b>, <b>&lt;&gt;</b>
    or <b>=</b>) at the beginning of each of your search values to specify how the comparison should be done.
</p>-->

<?php // echo CHtml::link('Advanced Search', '#', array('class' => 'search-button')); ?>
<div class="search-form">
    <?php
    $this->renderPartial('_search', array(
        'model' => $model,
    ));
    ?>
</div><!-- search-form -->

<?php
$this->widget('zii.widgets.grid.CGridView', array(
    'id' => 'account-flow-grid',
    'dataProvider' => $model->search(),
//    'filter' => $model,
    'columns' => array(
        'account_id',
        'gai_number',
        'account_name',
        'debit_amount',
        'credit_amount',
        array(
            'name' => 'create_time',
            'value' => 'date("Y-m-d H:i:s", $data->create_time)'
        ),
//        'debit_previous_amount_cash',
        'credit_previous_amount_cash',
//        'debit_current_amount_cash',
        'credit_current_amount_cash',
//        'debit_previous_amount_nocash',
        'credit_previous_amount_nocash',
//        'debit_current_amount_nocash',
        'credit_current_amount_nocash',
//        'debit_previous_amount_frezee',
//        'credit_previous_amount_frezee',
//        'debit_current_amount_frezee',
//        'credit_current_amount_frezee',
        'debit_previous_amount',
        'credit_previous_amount',
        'debit_current_amount',
        'credit_current_amount',
        array(
            'name' => 'operate_type',
            'value' => 'AccountFlow::showOperateType($data->operate_type)'
        ),
        'trade_space',
        'trade_terminal',
        'ratio',
        'target_id',
        array(
            'name' => 'owner_type',
            'value' => 'AccountFlow::showOwner($data->owner_type)'
        ),
        array(
            'name' => 'income_type',
            'value' => 'AccountFlow::showType($data->income_type)'
        ),
        array(
            'name' => 'score_source',
            'value' => 'AccountFlow::showSource($data->score_source)'
        ),
        'prepaid_card_version',
        'remark',
        'code',
        'serial_number'
    ),
));

Yii::app()->clientScript->registerCss('search', "
#content .grid-view table.items th {
    background-repeat: repeat
}
");
?>
