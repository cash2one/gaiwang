<?php
/* @var $this AccountFlowController */
/* @var $model AccountFlow */
/* @var $form CActiveForm */
?>

<div class="wide form">

    <?php
    $form = $this->beginWidget('CActiveForm', array(
        'action' => Yii::app()->createUrl($this->route),
        'method' => 'get',
    ));
    ?>

    <div class="row">
        <?php echo $form->label($model, 'gai_number'); ?>
        <?php echo $form->textField($model, 'gai_number', array('size' => 60, 'maxlength' => 64)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'account_name'); ?>
        <?php echo $form->textField($model, 'account_name', array('size' => 60, 'maxlength' => 128)); ?>
    </div>

    <!--    <div class="row">
    <?php // echo $form->label($model, 'account_type'); ?>
    <?php // echo $form->textField($model, 'account_type'); ?>
        </div>-->

    <!--    <div class="row">
    <?php // echo $form->label($model, 'operate_type'); ?>
    <?php // echo $form->radioButtonList($model, 'operate_type'); ?>
        </div>-->

    <!--    <div class="row">
    <?php echo $form->label($model, 'data_type'); ?>
    <?php // echo $form->radioButtonList($model, 'data_type'); ?>
        </div>-->

    <div class="row">
        <?php echo $form->label($model, 'owner_type'); ?>
        <?php echo $form->radioButtonList($model, 'owner_type', AccountFlow::getOwner(), array('separator' => ' ')); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'income_type'); ?>
        <?php echo $form->radioButtonList($model, 'income_type', AccountFlow::getSource(), array('separator' => ' ')); ?>
    </div>

    <!--<div class="row">-->
        <?php // echo $form->label($model, 'score_source'); ?>
        <?php // echo $form->textField($model, 'score_source'); ?>
    <!--</div>-->


    <div class="row buttons">
        <?php echo CHtml::submitButton('Search'); ?>
    </div>

    <?php $this->endWidget(); ?>

</div><!-- search-form -->