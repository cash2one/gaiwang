<?php
/* @var $this AccountBalanceController */
/* @var $model AccountBalance */

$this->breadcrumbs = array(
    'Account Balances' => array('index'),
    'Manage',
);

$this->menu = array(
    array('label' => 'List AccountBalance', 'url' => array('index')),
    array('label' => 'Create AccountBalance', 'url' => array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$('#account-balance-grid').yiiGridView('update', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<h1>Manage Account Balances</h1>

<p>
    You may optionally enter a comparison operator (<b>&lt;</b>, <b>&lt;=</b>, <b>&gt;</b>, <b>&gt;=</b>, <b>&lt;&gt;</b>
    or <b>=</b>) at the beginning of each of your search values to specify how the comparison should be done.
</p>

<?php // echo CHtml::link('Advanced Search', '#', array('class' => 'search-button')); ?>
<div class="search-form">
    <?php
    $this->renderPartial('_search', array(
        'model' => $model,
    ));
    ?>
</div><!-- search-form -->

<?php
$this->widget('zii.widgets.grid.CGridView', array(
    'id' => 'account-balance-grid',
    'dataProvider' => $model->search(),
//    'filter' => $model,
    'columns' => array(
        'account_id',
        'gai_number',
        'name',
        'debit_yesterday_amount_cash',
        'credit_yesterday_amount_cash',
        'debit_today_amount_cash',
        'credit_today_amount_cash',
        'debit_yesterday_amount_nocash',
        'credit_yesterday_amount_nocash',
        'debit_today_amount_nocash',
        'credit_today_amount_nocash',
        'debit_yesterday_amount_frezee',
        'credit_yesterday_amount_frezee',
        'debit_today_amount_frezee',
        'credit_today_amount_frezee',
        'debit_yesterday_amount',
        'credit_yesterday_amount',
        'debit_yesterday_amount',
        'credit_yesterday_amount',
        'debit_today_amount',
        'credit_today_amount',
        'return_amount',
        'owner_type',
        'remak',
//        array(
//            'class' => 'CButtonColumn',
//        ),
    ),
));
?>
