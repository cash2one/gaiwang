<?php
/* @var $this AccountBalanceController */
/* @var $model AccountBalance */
/* @var $form CActiveForm */
?>

<div class="wide form">

    <?php
    $form = $this->beginWidget('CActiveForm', array(
        'action' => Yii::app()->createUrl($this->route),
        'method' => 'get',
    ));
    ?>

<!--    <div class="row">
        <?php echo $form->label($model, 'id'); ?>
        <?php echo $form->textField($model, 'id', array('size' => 11, 'maxlength' => 11)); ?>
    </div>-->

    <div class="row">
        <?php echo $form->label($model, 'account_id'); ?>
        <?php echo $form->textField($model, 'account_id', array('size' => 11, 'maxlength' => 11)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'gai_number'); ?>
        <?php echo $form->textField($model, 'gai_number', array('size' => 60, 'maxlength' => 64)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'name'); ?>
        <?php echo $form->textField($model, 'name', array('size' => 60, 'maxlength' => 128)); ?>
    </div>

<!--    <div class="row">
        <?php echo $form->label($model, 'debit_yesterday_amount_cash'); ?>
        <?php echo $form->textField($model, 'debit_yesterday_amount_cash', array('size' => 18, 'maxlength' => 18)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'credit_yesterday_amount_cash'); ?>
        <?php echo $form->textField($model, 'credit_yesterday_amount_cash', array('size' => 18, 'maxlength' => 18)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'debit_today_amount_cash'); ?>
        <?php echo $form->textField($model, 'debit_today_amount_cash', array('size' => 18, 'maxlength' => 18)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'credit_today_amount_cash'); ?>
        <?php echo $form->textField($model, 'credit_today_amount_cash', array('size' => 18, 'maxlength' => 18)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'debit_yesterday_amount_nocash'); ?>
        <?php echo $form->textField($model, 'debit_yesterday_amount_nocash', array('size' => 18, 'maxlength' => 18)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'credit_yesterday_amount_nocash'); ?>
        <?php echo $form->textField($model, 'credit_yesterday_amount_nocash', array('size' => 18, 'maxlength' => 18)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'debit_today_amount_nocash'); ?>
        <?php echo $form->textField($model, 'debit_today_amount_nocash', array('size' => 18, 'maxlength' => 18)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'credit_today_amount_nocash'); ?>
        <?php echo $form->textField($model, 'credit_today_amount_nocash', array('size' => 18, 'maxlength' => 18)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'debit_yesterday_amount_frezee'); ?>
        <?php echo $form->textField($model, 'debit_yesterday_amount_frezee', array('size' => 18, 'maxlength' => 18)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'credit_yesterday_amount_frezee'); ?>
        <?php echo $form->textField($model, 'credit_yesterday_amount_frezee', array('size' => 18, 'maxlength' => 18)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'debit_today_amount_frezee'); ?>
        <?php echo $form->textField($model, 'debit_today_amount_frezee', array('size' => 18, 'maxlength' => 18)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'credit_today_amount_frezee'); ?>
        <?php echo $form->textField($model, 'credit_today_amount_frezee', array('size' => 18, 'maxlength' => 18)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'debit_yesterday_amount'); ?>
        <?php echo $form->textField($model, 'debit_yesterday_amount', array('size' => 18, 'maxlength' => 18)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'credit_yesterday_amount'); ?>
        <?php echo $form->textField($model, 'credit_yesterday_amount', array('size' => 18, 'maxlength' => 18)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'debit_today_amount'); ?>
        <?php echo $form->textField($model, 'debit_today_amount', array('size' => 18, 'maxlength' => 18)); ?>
    </div>

    <div class="row">
        <?php echo $form->label($model, 'credit_today_amount'); ?>
        <?php echo $form->textField($model, 'credit_today_amount', array('size' => 18, 'maxlength' => 18)); ?>
    </div>-->

<!--    <div class="row">
        <?php echo $form->label($model, 'return_amount'); ?>
        <?php echo $form->textField($model, 'return_amount', array('size' => 18, 'maxlength' => 18)); ?>
    </div>-->

    <div class="row">
        <?php echo $form->label($model, 'owner_type'); ?>
        <?php echo $form->textField($model, 'owner_type'); ?>
    </div>

<!--    <div class="row">
        <?php echo $form->label($model, 'remak'); ?>
        <?php echo $form->textArea($model, 'remak', array('rows' => 6, 'cols' => 50)); ?>
    </div>-->

    <div class="row buttons">
        <?php echo CHtml::submitButton('Search'); ?>
    </div>

    <?php $this->endWidget(); ?>

</div><!-- search-form -->